
<header>
        <ul>
            <li>Carne 100% de Madrid</li>
            <li>Carnicería Villa granado</li>
            <li>Los mejores precios</li>

        </ul>
    </header>
    <nav>
        <a href="https://enlavaguada.com/"><img src="/proyecto-la-vaguada/img/General/logo.jpeg" alt="Logo la Vaguada"></a>
        <div class="menu">
            <a href="/proyecto-la-vaguada/HTML/sobrenosotros.php">Inicio</a>
            <div class="desplegable">
                <button class="desplegar"><a href="/proyecto-la-vaguada/HTML/Carnes/carnes.php">Carnicería
                        <i class="fa fa-caret-down"></i>
                    </a>

                </button>
                <div class="desplegados">
                    <a href="/proyecto-la-vaguada/HTML/Carnes/carnes.php#Corderos">Cordero</a>
                    <a href="/proyecto-la-vaguada/HTML/Carnes/carnes.php#Cerdos">Cerdo</a>
                    <a href="/proyecto-la-vaguada/HTML/Carnes/carnes.php#Ternera">Ternera</a>
                </div>
            </div>
            <div class="desplegable">
                <button class="desplegar"><a href="/proyecto-la-vaguada/HTML/Pollos/pollos.php">Pollería
                        <i class="fa fa-caret-down"></i>
                    </a>

                </button>
                <div class="desplegados">
                    <a href="/proyecto-la-vaguada/HTML/Pollos/pollos.php#populares">Populares</a>
                    <a href="/proyecto-la-vaguada/HTML/Pollos/pollos.php#simples">Simples</a>
                    <a href="/proyecto-la-vaguada/HTML/Pollos/pollos.php#tipicos">Típicos</a>
                    <a href="/proyecto-la-vaguada/HTML/Pollos/pollos.php#elaborados">Elaborados</a>
                </div>
            </div>
            <div class="desplegable">
                <button class="desplegar"><a href="/proyecto-la-vaguada/HTML/Quesos/quesos.php">Quesos
                        <i class="fa fa-caret-down"></i>
                    </a>

                </button>
                <div class="desplegados">
                    <a href="/proyecto-la-vaguada/HTML/Quesos/quesos.php#Quesos1">Quesos de oveja</a>
                    <a href="/proyecto-la-vaguada/HTML/Quesos/quesos.php#Quesos2">Elaborados</a>
                    <a href="/proyecto-la-vaguada/HTML/Quesos/quesos.php#relacionados">Relacionados</a>

                </div>
            </div>
            <div class="desplegable">
                <button class="desplegar"><a href="/proyecto-la-vaguada/HTML/Charcuteria/charcuteria.php">Charcutería <i
                            class="fa fa-caret-down"></i></a>

                </button>
                <div class="desplegados">
                    <a href="/proyecto-la-vaguada/HTML/Charcuteria/charcuteria.php#embutidos">Embutidos</a>
                    <a href="/proyecto-la-vaguada/HTML/Charcuteria/charcuteria.php#partes">Partes</a>
                    <a href="/proyecto-la-vaguada/HTML/Charcuteria/charcuteria.php#preparados">Preparados</a>
                </div>
            </div>





        </div>

    </nav>
